# Python directory

This folder contains the files and scripts to create the `cvui` Python package that can be installed using `pip`.
